-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2024 at 09:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `certificates_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `reference_id` varchar(255) NOT NULL,
  `certificate_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `course_name` varchar(255) DEFAULT NULL,
  `batch` varchar(255) DEFAULT NULL,
  `institute` varchar(255) DEFAULT NULL,
  `end_course_date` date DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `CertificatePDF` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`reference_id`, `certificate_number`, `name`, `course_name`, `batch`, `institute`, `end_course_date`, `avatar`, `CertificatePDF`) VALUES
('hcygtccgc', '1025', 'Jane Smith', 'Data Science', '2023B', 'ABC Institute', '2023-11-30', 'https://zidanesewing.com/avatar/avatar_03.jpg', 'https://zidanesewing.com/avatar/avatar_03.pdf'),
('REF123', 'CERT123', 'John Doe', 'Web Development', '2023A', 'XYZ Institute', '2023-12-31', 'https://example.com/avatar.jpg', 'https://example.com/certificate.pdf'),
('REF456', 'CERT456', 'Jane Smith', 'Data Science', '2023B', 'ABC Institute', '2023-11-30', 'https://example.com/avatar2.jpg', 'https://example.com/certificate2.pdf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`reference_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
