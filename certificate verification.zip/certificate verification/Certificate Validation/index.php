<?php
$show_detail = FALSE;

// Get the reference ID from the query parameter
$reference_id = filter_input(INPUT_GET, 'rid', FILTER_SANITIZE_STRING);

// Database connection parameters
$host = 'localhost'; // Update with your host
$db = 'certificates_db'; // Update with your database name
$user = 'certificates_db'; // Update with your database user
$pass = 'yRGh]pAiX1)N3SZ_'; // Update with your database password

if ($reference_id) {
    // Create a new PDO connection
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare and execute the query
        $stmt = $pdo->prepare("SELECT * FROM users WHERE reference_id = :reference_id");
        $stmt->execute(['reference_id' => $reference_id]);

        // Fetch the result
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $show_detail = TRUE;
            $certificate_number = htmlspecialchars($result['certificate_number']);
            $name = htmlspecialchars($result['name']);
            $course_name = htmlspecialchars($result['course_name']);
            $batch = htmlspecialchars($result['batch']);
            $institute = htmlspecialchars($result['institute']);
            $end_course_date = htmlspecialchars($result['end_course_date']);
            $avatar = empty($result['avatar']) ? "https://learnwithnoman.com/ptupiksy/2024/06/Learn-with-Noman-logo.png" : htmlspecialchars($result['avatar']);
            $CertificatePDF = htmlspecialchars($result['CertificatePDF']);
            $valid="✔ Certificate valid.";
        } else {
            $error = " Certificate not valid ";
        }

    } catch (PDOException $e) {
        $error = "Error connecting to the database: " . $e->getMessage();
    }
} else {
    $error = "Certificate not valid.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="includes/css/style.css">
    <title>Certificate Details</title>
</head>
<body>
    <div class="container bootstrap snippet" id="printableArea">
        <img src="includes/img/Learn with Noman logo.png" alt="Logo" class="img-logo">
        <h1 class="Text-style">Certificate Details</h1>
        <div class="panel-body inf-content">
            <div class="row">
                <?php if (isset($error)): ?>
                    <div class="col-md-12 text-center">
                        <img src="includes/img/preloader.gif" alt="Error" style="width:250px;height:250px;">
                        <h1 class="foder"><?php echo htmlspecialchars($error); ?></h1>
                    </div>
                <?php elseif ($show_detail): ?>
                    <div class="col-md-3 text-center">
                        <img alt="" style="width:250px;height:234px;" title="" class="img-circle img-thumbnail" src="<?php echo $avatar; ?>">
                    </div>
                    <div class="col-md-9">
                        <div class="table-responsive">
                            <table class="table table-user-information">
                                <tbody>
                                    <tr>
                                        <td><strong>Certificate Number :</strong></td>
                                        <td class="text-primary"><?php echo $certificate_number; ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Name :</strong></td>
                                        <td class="text-primary"><?php echo $name; ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Course Name :</strong></td>
                                        <td class="text-primary"><?php echo $course_name; ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Batch :</strong></td>
                                        <td class="text-primary"><?php echo $batch; ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Institute :</strong></td>
                                        <td class="text-primary"><?php echo $institute; ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>End Course Date :</strong></td>
                                        <td class="text-primary"><?php echo $end_course_date; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="container1">
                        <h4 class="valid"><?php echo  $valid; ?></h4>
                    </div>
                    <div class="download-buttons1">
                        <button onclick="printDiv('printableArea')" class="download-button1"><i class="fas fa-file-image">Print</i></button>
                        <a href="<?php echo $CertificatePDF; ?>" class="download-button1"><i class="fas fa-file-pdf"></i> Download PDF</a>
                    </div>
                <?php else: ?>
                    <div class="col-md-12 text-center">
                        <img src="includes/img/preloader.gif" alt="Certificate not valid" style="width:250px;height:250px;">
                        <h1 class="foder">Certificate not valid</h1>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script>
        function printDiv(printableArea) {
            var printContents = document.getElementById(printableArea).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>
</body>
</html>
